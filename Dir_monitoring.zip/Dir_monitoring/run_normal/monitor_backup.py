import os
import time
import hashlib#to hash the file
import requests# to http request from totalvirus website
import configparser#used for working with configuration files
from watchdog.observers import Observer# monitor the DIR 
from watchdog.events import FileSystemEventHandler
from tqdm import tqdm #add progress bars to your code
import json
import ctypes # notification library


config = configparser.ConfigParser()
config.read("config.ini")

# Get API key for virus total from configuration file
API_KEY = config["VIRUSTOTAL"]["API_KEY"]#Holds the API key for accessing the VirusTotal service.
# # Get the downloads directory from configuration file
DOWNLOADS_DIR = config["DEFAULT"]["DOWNLOADS_DIR"]
FILES_DATA = os.path.join(DOWNLOADS_DIR, "files_data.json")#Represents the path to the JSON file (files_data.json) that stores information about previously scanned files.


BLOCK_SIZE = 65536

#The function calculate_file_hash takes a file path as input and calculates the SHA-256 hash value of the file. 
def calculate_file_hash(file_path):
    hash_func = hashlib.sha256()
    with open(file_path, "rb") as f:#It opens the file in binary mode and ensures that the file is read in binary mode
        block = f.read(BLOCK_SIZE)
        while block:# diivide the binary file into blocks of 65536 bits then add them together
            hash_func.update(block)
            block = f.read(BLOCK_SIZE)
    return hash_func.hexdigest()#convert the binary file into hexadecimal
    
#The scan_file function is responsible for uploading a file to the VirusTotal API for scanning
def scan_file(file_path):
    url = "https://www.virustotal.com/vtapi/v2/file/scan"
    params = {"apikey": API_KEY}#he params dictionary contains the parameters to be passed in the API request
    files = {"file": (os.path.basename(file_path), open(file_path, "rb"))}#The files dictionary is used to specify the file to be uploaded
    response = requests.post(url, data=files, params=params)#The requests.post function sends a POST request to the VirusTotal API
    return response.json()# the function returns the JSON response obtained from the VirusTotal API.


def get_scan_report(resource):#get report from totalvirus 
    url = "https://www.virustotal.com/vtapi/v2/file/report"
    params = {"apikey": API_KEY, "resource": resource}
    response = requests.get(url, params=params)
    #print(response.json())
    return response.json()


class DownloadHandler(FileSystemEventHandler):
    def on_created(self, event):
        try:
            if not event.is_directory:
                extensions = []
                with open(FILES_DATA, "r") as f:
                    content = json.load(f)

                # Scanning Conditions
                execlude_init_files = lambda x: (#to do not scan desktop.ini and files_data.json
                    os.path.basename(x) != "desktop.ini"
                ) and (os.path.basename(x) != "files_data.json")

                already_known = lambda x: x in list(content)
                already_scanned = lambda x: content[x] == os.path.getctime(
                    os.path.join(DOWNLOADS_DIR, x)
                )
                #this for loop to loop into a list "content" that contains json file of the files that already scanned
                for file_name in os.listdir(DOWNLOADS_DIR):
                    file_name = os.path.join(DOWNLOADS_DIR, file_name)
                    if execlude_init_files(file_name):
                        if not (
                            already_known(file_name) and already_scanned(file_name)
                        ):
                            extensions.append(
                                (
                                    os.path.splitext(file_name)[0],
                                    os.path.splitext(file_name)[1],
                                )
                            )
                            content[file_name] = os.path.getctime(
                                os.path.join(DOWNLOADS_DIR, file_name)
                            )
                            with open(FILES_DATA, "w") as f:
                                json.dump(content, f, indent=4)
                
                #if the file has extension 
                #split the file into two object/ extension[0] is the name of the file and extension[1] is the extension of the file
                for extension in tqdm(extensions):
                    if extension[1]: 
                        try:
                            
                            file_path = os.path.join(
                                DOWNLOADS_DIR, f"{extension[0]}{extension[1]}"
                            )
                            
                            file_hash = calculate_file_hash(file_path)
                            scan_result = get_scan_report(file_hash)

                            if  scan_result["response_code"]: #calling the method scan_result that contains get scan report of the file_hash
                            #if response code == 0 then the file is safe
                                print(f"{os.path.basename(file_path)} is safe.")
                                
                            #else the code is not safe
                            else:
                                print( f"{os.path.basename(file_path)} contains virus or malware.")
                                #to display the notification
                                response = ctypes.windll.user32.MessageBoxW(None, f'The file "{file_path}" is infected with a virus/malware.\nDo you want to delete it?', 'Virus/Malware Alert!', 0x40 | 0x1)

                                time.sleep(3)#this time.sleep because when download a file it take time to get the real name 
                                if response:
                                    os.remove(file_path)
                                    print(f'{file_path} deleted.')
                                else:
                                    print(f'{file_path} not deleted.')

                        except Exception as e:
                            print(f"An error occurred: {str(e)}")
                            

                    else:
                        print("extension ==== ", extension[1])
                        print("error in extension")
                        
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            


event_handler = DownloadHandler()# a class object that fires up on the detecting the new downloaded file, then scan it
observer = Observer()
observer.schedule(event_handler, path=DOWNLOADS_DIR)
observer.start()#watchdog start monitoring

#The code you provided sets up an infinite loop that keeps the program running until a keyboard interrupt (Ctrl+C) is detected
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    observer.stop()
observer.join()
