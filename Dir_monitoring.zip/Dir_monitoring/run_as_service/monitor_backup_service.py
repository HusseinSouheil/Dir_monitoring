import os
import time
import hashlib
import requests
import configparser
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from win10toast import ToastNotifier
from tqdm import tqdm
import json

toaster = ToastNotifier()


config = configparser.ConfigParser()
config.read("config.ini")

# Get API key for virus total from configuration file
API_KEY = config["VIRUSTOTAL"]["API_KEY"]
# # Get the downloads directory from configuration file
DOWNLOADS_DIR = config["DEFAULT"]["DOWNLOADS_DIR"]
FILES_DATA = os.path.join(DOWNLOADS_DIR, "files_data.json")


BLOCK_SIZE = 65536


def calculate_file_hash(file_path):
    hash_func = hashlib.sha256()
    with open(file_path, "rb") as f:
        block = f.read(BLOCK_SIZE)
        while block:
            hash_func.update(block)
            block = f.read(BLOCK_SIZE)
    return hash_func.hexdigest()


def scan_file(file_path):
    url = "https://www.virustotal.com/vtapi/v2/file/scan"
    params = {"apikey": API_KEY}
    files = {"file": (os.path.basename(file_path), open(file_path, "rb"))}
    response = requests.post(url, data=files, params=params)
    return response.json()


def get_scan_report(resource):
    url = "https://www.virustotal.com/vtapi/v2/file/report"
    params = {"apikey": API_KEY, "resource": resource}
    response = requests.get(url, params=params)
    # print("response === == == ",response.json())
    return response.json()


class DownloadHandler(FileSystemEventHandler):
    def on_created(self, event):
        # with context.supres9s(Exception):
        try:
            if not event.is_directory:
                file_paths = []
                if os.path.isdir(event.src_path):
                    for root, dirs, files in os.walk(event.src_path):
                        for file in files:
                            file_path = os.path.join(root, file)
                            file_paths.append(file_path)
                else:
                    file_paths.append(event.src_path)

                extensions = []
                with open(FILES_DATA, "r") as f:
                    content = json.load(f)

                # Scanning Conditions
                execlude_init_files = lambda x: (
                    os.path.basename(x) != "desktop.ini"
                ) and (os.path.basename(x) != "files_data.json")

                already_known = lambda x: x in list(content)
                already_scanned = lambda x: content[x] == os.path.getctime(
                    os.path.join(DOWNLOADS_DIR, x)
                )

                for file_name in os.listdir(DOWNLOADS_DIR):
                    file_name = os.path.join(DOWNLOADS_DIR, file_name)
                    if execlude_init_files(file_name):
                        if not (
                            already_known(file_name) and already_scanned(file_name)
                        ):
                            extensions.append(
                                (
                                    os.path.splitext(file_name)[0],
                                    os.path.splitext(file_name)[1],
                                )
                            )
                            content[file_name] = os.path.getctime(
                                os.path.join(DOWNLOADS_DIR, file_name)
                            )
                            with open(FILES_DATA, "w") as f:
                                json.dump(content, f, indent=4)
                print(extensions)
                # get_files_data = {
                #     os.path.join(DOWNLOADS_DIR, file_name): os.path.getctime(
                #         os.path.join(DOWNLOADS_DIR, file_name)
                #     )
                #     for file_name in os.listdir(DOWNLOADS_DIR)
                # }
                # print(get_files_data)

                for extension in tqdm(extensions):
                    if extension[
                        1
                    ]:  # in ('exe', 'msi', 'pdf', 'zip', 'py', 'docx', 'tmp', 'ini', 'pka', 'rar'):
                        try:
                            file_path = os.path.join(
                                DOWNLOADS_DIR, f"{extension[0]}{extension[1]}"
                            )
                            # if file_path in list(content):
                            #     if content[file_path] == os.path.getctime(
                            #         os.path.join(DOWNLOADS_DIR, file_path)
                            #     ):
                            #         print(f"The file {file_path} is already scanned")
                            #         pass

                            # else:
                            print(f"Scanning the file {file_path}")
                            file_hash = calculate_file_hash(file_path)
                            scan_result = get_scan_report(file_hash)

                            if not scan_result["response_code"]:
                                print(f"{os.path.basename(file_path)} is safe.")

                            else:
                                print(
                                    f"{os.path.basename(file_path)} contains virus or malware."
                                )
                                toaster.show_toast(
                                    "File contains virus/malware",
                                    f"{os.path.basename(file_path)} may contain virus/malware. Do you want to delete it?",
                                    duration=20,
                                    icon_path=None,
                                )

                        except:
                            pass

                    else:
                        print("extension ==== ", extension[1])
                        print("error in extension")
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            pass
